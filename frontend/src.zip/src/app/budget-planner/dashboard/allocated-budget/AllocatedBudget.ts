export class AllocatedBudget{
  userId:string = '';
  monthAndYear: string = '';
  expenseType: string = '';
  amount: number = 0;

}
