export class Expenditure {
    userId!: string;
    amount!: number;
    expenseType!: string;
    monthAndYear!: Date;
}