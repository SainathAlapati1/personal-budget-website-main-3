export class Earnings {
  month: number = 0;
  year: number = 0;
  amount: number = 0;
  userId: string = '';
}
