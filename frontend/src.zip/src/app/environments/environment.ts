export const defaultEnvironment = {
  firebaseConfig: {
    apiKey: 'AIzaSyBxcKh0ESa2prKJ4j-xhKxmwo5XTe2Hizw',
    authDomain: 'personal-budget-application.firebaseapp.com',
    projectId: 'personal-budget-application',
    storageBucket: 'personal-budget-application.appspot.com',
    messagingSenderId: '362355297871',
    appId: '1:362355297871:web:c4fea06d7fb49da9f3643a',
    measurementId: 'G-QNL0QXF0SV',
  },
  production: false,
};
